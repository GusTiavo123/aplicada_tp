#!/bin/bash

esLaborable() {
	if grep -q $1 "feriados.txt" || ($1 +%w) == "6" || ($1 +%w) == "7"; then
		echo "La fecha ingresada no es un día laborable"
	else
		echo "La fecha ingresada es un día laborable"
	fi
}