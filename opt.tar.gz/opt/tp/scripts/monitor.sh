#!/bin/bash

proceso=$(ps | grep $1 | wc -l)

while true
do
	if [[ $proceso -gt 0 ]] ; then
		echo "El proceso está corriendo"
	else
		`mail -s "El proceso no esta corriendo" root@192.168.56.101`
	fi
	sleep 300
done
