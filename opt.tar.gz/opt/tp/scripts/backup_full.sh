#!/bin/sh
#script de backup

#Declaro las variables necesarios para llevar a cabo el script
ORIGEN="$1"
DESTINO="$2"
FECHA="$(date +%Y%m%d)"
BACKUP_FILE="$ORIGEN"_bkp_"$FECHA".tgz
LOG_NAME=se_crea_bkp_de_"$ORIGEN"

#creo y envio el log por mail
logger $LOG_NAME 
mail -s `tail -1 /var/log/syslog` root@192.168.56.101 

#Verifico que el origen y el destino ingresados existan
if [ ! -d "$ORIGEN"] && [ ! -d "$DESTINO"]; then

	#En caso de que no existan se cancela el script
	exit 1
fi

#Creo el bkp
tar czf $DESTINO/$BACKUP_FILE $ORIGEN


